'use strict';

const UserManagement = (() => {
  let users = [], search = '', statusFilter = 'all';
  function statusLabel(status) { return ({active:'نشط', suspended:'موقوف مؤقتًا', pending:'بانتظار التفعيل', disabled:'معطّل'})[status] || status; }
  async function init() {
    if (!Permissions.can('users.manage')) return;
    await refresh();
    document.getElementById('usersTableBody').addEventListener('click', onAction);
    document.getElementById('usersSearch').addEventListener('input', e => { search = e.target.value.toLowerCase(); render(); });
    document.getElementById('usersStatusFilter').addEventListener('change', e => { statusFilter = e.target.value; render(); });
    document.getElementById('refreshUsersBtn').addEventListener('click', refresh);
    document.getElementById('userEditorCancelBtn').addEventListener('click', close);
    document.getElementById('userEditorForm').addEventListener('submit', save);
  }
  async function refresh() {
    Permissions.require('users.manage');
    const snap = await db.collection(COLLECTIONS.USERS).orderBy('email').get();
    users = snap.docs.map(d => ({ id:d.id, ...d.data() })); render();
  }
  function render() {
    const body = document.getElementById('usersTableBody'); if (!body) return;
    const shown = users.filter(u => (!search || String(u.email || u.id).toLowerCase().includes(search)) && (statusFilter === 'all' || (u.status || 'active') === statusFilter));
    body.innerHTML = shown.map(u => `<tr><td>${Utils.escapeHtml(u.email || u.id)}</td><td>${Utils.escapeHtml(Permissions.ROLES[Permissions.profileRole(u)].label)}</td><td><span class="badge">${Utils.escapeHtml(statusLabel(u.status || 'active'))}</span></td><td>${(u.permissions || Permissions.effective(Permissions.profileRole(u), u.permissionOverrides)).length}</td><td><button class="btn btn-sm" data-user-id="${u.id}">تعديل</button></td></tr>`).join('') || '<tr><td colspan="5" class="empty-cell">لا توجد حسابات.</td></tr>';
  }
  function onAction(e) { const btn=e.target.closest('[data-user-id]'); if (btn) open(btn.dataset.userId); }
  function open(id) {
    const u=users.find(x=>x.id===id); if (!u) return;
    document.getElementById('userEditorId').value=id;
    document.getElementById('userEditorEmail').textContent=u.email || id;
    document.getElementById('userRoleSelect').value=Permissions.profileRole(u);
    document.getElementById('userStatusSelect').value=u.status || 'active';
    document.getElementById('userAllowInput').value=(u.permissionOverrides?.allow || []).join(', ');
    document.getElementById('userDenyInput').value=(u.permissionOverrides?.deny || []).join(', ');
    renderPermissionGroups(u);
    document.getElementById('userEditorModal').classList.add('open');
  }
  function close() { document.getElementById('userEditorModal').classList.remove('open'); }
  function split(value) { return [...new Set(String(value || '').split(',').map(x=>x.trim()).filter(Boolean))]; }
  function renderPermissionGroups(u) {
    const groups = { 'الموظفون':['employees.read','employees.write','employees.delete'], 'الطلبات':['orders.read','orders.import','orders.write'], 'الشهور':['months.read','months.write','months.destructive'], 'التقارير':['reports.read','reports.calculate','reports.export','reports.approve'], 'المالية':['transactions.read','transactions.write','settlements.read','settlements.write'], 'النسخ والأرشيف':['backups.read','backups.create','backups.download','backups.restore','archive.read','comparison.read'], 'الإدارة':['audit.read','settings.read','settings.write','users.manage'] };
    const allow = new Set(u.permissionOverrides?.allow || []), deny = new Set(u.permissionOverrides?.deny || []);
    document.getElementById('permissionGroups').innerHTML = Object.entries(groups).map(([name, list]) => `<section><h4>${name}</h4>${list.map(p => `<label>${p}<select data-permission="${p}"><option value="default">افتراضي</option><option value="allow" ${allow.has(p) ? 'selected' : ''}>منح</option><option value="deny" ${deny.has(p) ? 'selected' : ''}>سحب</option></select></label>`).join('')}</section>`).join('');
  }
  async function save(e) {
    e.preventDefault(); Permissions.require('users.manage');
    const id=document.getElementById('userEditorId').value, role=Permissions.normalizeRole(document.getElementById('userRoleSelect').value);
    const status=document.getElementById('userStatusSelect').value;
    const permissionOverrides={ allow:split(document.getElementById('userAllowInput').value), deny:split(document.getElementById('userDenyInput').value) };
    document.querySelectorAll('#permissionGroups select[data-permission]').forEach(select => {
      if (select.value === 'allow') permissionOverrides.allow.push(select.dataset.permission);
      if (select.value === 'deny') permissionOverrides.deny.push(select.dataset.permission);
    });
    permissionOverrides.allow = [...new Set(permissionOverrides.allow)].filter(p => !permissionOverrides.deny.includes(p));
    permissionOverrides.deny = [...new Set(permissionOverrides.deny)];
    await db.collection(COLLECTIONS.USERS).doc(id).update({ role, systemRole: role === 'super_admin' ? 'super_admin' : null, status, permissionOverrides, permissions: Permissions.effective(role, permissionOverrides), updatedAt: firebase.firestore.FieldValue.serverTimestamp() });
    close(); await refresh(); Toast.show('تم حفظ دور وصلاحيات المستخدم.', 'success');
  }
  return { init, refresh };
})();
