/*
 * orders.js
 * -----------------------------------------------------------------------
 * Orders Management for the existing `monthly_reports/{month}/orderBatches`
 * storage model. Orders stay embedded in their import batch intentionally:
 * that preserves the proven import/report pipeline while this module offers
 * a paginated, searchable operational view over those rows.
 * -----------------------------------------------------------------------
 */

'use strict';

const OrdersManagement = (() => {
  const PAGE_SIZE = 50;
  const state = {
    initialized: false,
    loading: false,
    busy: false,
    orders: [],
    batches: new Map(),
    page: 1,
    callbacks: null
  };

  function timestampMillis(value) {
    if (!value) return 0;
    if (typeof value.toDate === 'function') return value.toDate().getTime();
    if (value instanceof Date) return value.getTime();
    const parsed = new Date(value).getTime();
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function formatDate(value) {
    const ms = timestampMillis(value);
    return ms ? new Date(ms).toLocaleString('ar-EG') : '—';
  }

  function money(value) {
    return `${Utils.formatNumber(Number(value || 0))} ج.م`;
  }

  function employeeMap() {
    return new Map((state.callbacks.getEmployees() || []).map(employee => [employee.id, employee]));
  }

  function departmentName(id, fallback = '') {
    if (!id) return fallback || '—';
    const department = (state.callbacks.getDepartments() || []).find(d => d.id === id);
    return department ? department.name : (fallback || '—');
  }

  function orderId(batchId, item, index) {
    return item.orderId || `legacy-${batchId}-${index + 1}`;
  }

  function normalizeBatch(doc) {
    const data = doc.data() || {};
    const monthId = data.monthId || (doc.ref.parent.parent ? doc.ref.parent.parent.id : null);
    const importedAt = data.importedAt || data.createdAt || null;
    const batch = {
      id: doc.id,
      ref: doc.ref,
      monthId,
      importedAt,
      importedBy: data.importedBy || data.createdBy || 'غير معروف',
      importId: data.importId || null,
      updatedAt: data.updatedAt || null,
      updatedBy: data.updatedBy || null,
      autoCreatedEmployeeIds: Array.isArray(data.autoCreatedEmployeeIds) ? data.autoCreatedEmployeeIds : [],
      count: Array.isArray(data.items) ? data.items.length : Number(data.count || 0),
      items: Array.isArray(data.items) ? data.items : []
    };
    return batch;
  }

  async function fetchAllBatchDocs() {
    // The application already maintains a small, authorised month index.
    // Reading each known month's direct subcollection avoids a collection-
    // group query while retaining the existing least-privilege Rules path.
    const monthIds = Array.from(new Set(Months.all().map(month => month.id).filter(Boolean)));
    const snapshots = await Promise.all(monthIds.map(monthId =>
      db.collection(COLLECTIONS.MONTHLY_REPORTS).doc(monthId)
        .collection(MONTH_SUBCOLLECTIONS.ORDER_BATCHES).get()
    ));
    return snapshots.flatMap(snapshot => snapshot.docs);
  }

  function flattenBatch(batch, employees) {
    return batch.items.map((item, index) => {
      const employee = employees.get(item.moderatorId) || null;
      const departmentId = item.departmentId || (employee ? employee.departmentId : null);
      return {
        id: orderId(batch.id, item, index),
        persistedId: item.orderId || null,
        legacyIndex: index,
        batchId: batch.id,
        batchRef: batch.ref,
        monthId: batch.monthId,
        importedAt: batch.importedAt,
        importedBy: batch.importedBy,
        batchUpdatedAt: batch.updatedAt,
        batchUpdatedBy: batch.updatedBy,
        moderatorId: item.moderatorId || null,
        moderatorName: item.moderatorName || (employee ? employee.name : 'غير معروف'),
        departmentId,
        departmentName: item.departmentName || departmentName(departmentId, employee ? departmentName(employee.departmentId) : ''),
        packages: Number(item.packages || 0),
        price: Number(item.price || 0),
        saleValue: Number(item.saleValue === undefined ? item.price : item.saleValue),
        orderDate: item.orderDate || '', externalOrderNumber: item.externalOrderNumber || item.orderNumber || '',
        customerName: item.customerName || '', customerPhone: item.customerPhone || '', notes: item.notes || '',
        fullAddress: item.fullAddress || item.address || '', productName: item.productName || item.product || '',
        waybillNumber: item.waybillNumber || '', governorate: item.governorate || '',
        shipmentStatus: item.shipmentStatus || 'لم يتم التحديث',
        updatedAt: item.updatedAt || batch.updatedAt || null,
        updatedBy: item.updatedBy || batch.updatedBy || null
      };
    });
  }

  async function load() {
    if (state.loading) return;
    state.loading = true;
    renderLoading();
    try {
      // Batch documents are compact; rows are flattened in memory but only
      // one 50-row page is rendered, keeping the DOM small for thousands of
      // orders.
      const docs = await fetchAllBatchDocs();
      const employees = employeeMap();
      const batches = docs.map(normalizeBatch)
        .sort((a, b) => timestampMillis(b.importedAt) - timestampMillis(a.importedAt));
      state.batches = new Map(batches.map(batch => [batch.id, batch]));
      state.orders = batches.flatMap(batch => flattenBatch(batch, employees));
      renderFilterOptions();
      render();
    } catch (err) {
      console.error('Orders load failed:', err);
      Toast.show('تعذر تحميل الطلبات: ' + err.message, 'error');
      renderEmpty('تعذر تحميل الطلبات');
    } finally {
      state.loading = false;
    }
  }

  function filterValue(id) {
    const element = document.getElementById(id);
    return element ? String(element.value || '').trim() : '';
  }

  function filteredOrders() {
    const term = Utils.normalizeName(filterValue('ordersSearchInput'));
    const monthId = filterValue('ordersMonthFilter');
    const departmentId = filterValue('ordersDepartmentFilter');
    const moderatorId = filterValue('ordersModeratorFilter');
    const batchId = filterValue('ordersBatchFilter');
    return state.orders.filter(order => {
      const search = !term ||
        Utils.normalizeName(order.moderatorName).includes(term) ||
        Utils.normalizeName(order.id).includes(term) ||
        Utils.normalizeName(order.externalOrderNumber).includes(term) ||
        Utils.normalizeName(order.customerName).includes(term) ||
        Utils.normalizeName(order.customerPhone).includes(term) ||
        Utils.normalizeName(order.productName).includes(term);
      return search &&
        (!monthId || order.monthId === monthId) &&
        (!departmentId || order.departmentId === departmentId) &&
        (!moderatorId || order.moderatorId === moderatorId) &&
        (!batchId || order.batchId === batchId);
    });
  }

  function renderFilterOptions() {
    const selections = [
      ['ordersMonthFilter', state.orders.map(order => [order.monthId, Utils.monthLabelFromId(order.monthId)])],
      ['ordersDepartmentFilter', Array.from(new Map(state.orders.map(order => [order.departmentId, order.departmentName])).entries())],
      ['ordersModeratorFilter', Array.from(new Map(state.orders.map(order => [order.moderatorId, order.moderatorName])).entries())],
      ['ordersBatchFilter', Array.from(new Map(state.orders.map(order => [order.batchId, order.batchId])).entries())]
    ];
    selections.forEach(([id, options]) => {
      const select = document.getElementById(id);
      if (!select) return;
      const previous = select.value;
      const unique = Array.from(new Map(options.filter(([value]) => value)).entries())
        .sort((a, b) => String(a[1]).localeCompare(String(b[1]), 'ar'));
      select.innerHTML = '<option value="">الكل</option>' + unique.map(([value, label]) =>
        `<option value="${Utils.escapeHtml(value)}">${Utils.escapeHtml(label || 'غير محدد')}</option>`
      ).join('');
      if (unique.some(([value]) => value === previous)) select.value = previous;
    });
  }

  function renderLoading() {
    const body = document.getElementById('ordersTableBody');
    if (body) body.innerHTML = '<tr><td colspan="13" class="empty-state">جاري تحميل الطلبات…</td></tr>';
  }

  function renderEmpty(message) {
    const body = document.getElementById('ordersTableBody');
    if (body) body.innerHTML = `<tr><td colspan="13" class="empty-state">${Utils.escapeHtml(message)}</td></tr>`;
  }

  function orderRow(order) {
    const locked = Months.isLocked(order.monthId);
    const disabled = state.busy || locked ? 'disabled' : '';
    return `<tr data-order-id="${Utils.escapeHtml(order.id)}">
      <td>${Utils.escapeHtml(order.orderDate || '—')}</td>
      <td class="orders-id">${Utils.escapeHtml(order.externalOrderNumber || order.id)}</td>
      <td>${Utils.escapeHtml(order.customerName || '—')}</td>
      <td>${Utils.escapeHtml(order.customerPhone || '—')}</td>
      <td>${Utils.escapeHtml(order.productName || '—')}</td>
      <td>${Utils.formatNumber(order.packages)}</td>
      <td>${money(order.price)}</td>
      <td>${Utils.escapeHtml(order.moderatorName)}</td>
      <td>${Utils.escapeHtml(order.departmentName)}</td>
      <td>${Utils.escapeHtml(order.waybillNumber || '—')}</td>
      <td>${Utils.escapeHtml(order.governorate || '—')}</td>
      <td>${Utils.escapeHtml(order.shipmentStatus)}</td>
      <td class="actions-cell">
        <button class="btn-icon" data-order-action="details" data-order-id="${Utils.escapeHtml(order.id)}" title="التفاصيل">👁️</button>
        <button class="btn-icon" data-order-action="edit" data-order-id="${Utils.escapeHtml(order.id)}" title="تعديل" ${disabled}>✏️</button>
        <button class="btn-icon btn-danger" data-order-action="delete" data-order-id="${Utils.escapeHtml(order.id)}" title="حذف" ${disabled}>🗑️</button>
      </td>
    </tr>`;
  }

  function render() {
    const result = filteredOrders();
    const totalPages = Math.max(1, Math.ceil(result.length / PAGE_SIZE));
    state.page = Math.min(state.page, totalPages);
    const pageRows = result.slice((state.page - 1) * PAGE_SIZE, state.page * PAGE_SIZE);
    const body = document.getElementById('ordersTableBody');
    if (!body) return;
    body.innerHTML = pageRows.length ? pageRows.map(orderRow).join('') :
      '<tr><td colspan="13" class="empty-state">لا توجد طلبات مطابقة للفلاتر الحالية</td></tr>';
    document.getElementById('ordersCountLabel').textContent = `${Utils.formatNumber(result.length)} طلب`;
    document.getElementById('ordersPageLabel').textContent = `صفحة ${state.page} من ${totalPages}`;
    document.getElementById('ordersPrevBtn').disabled = state.page <= 1;
    document.getElementById('ordersNextBtn').disabled = state.page >= totalPages;
    renderBatches(result);
  }

  function renderBatches(visibleOrders) {
    const body = document.getElementById('ordersBatchesBody');
    if (!body) return;
    const visibleIds = new Set(visibleOrders.map(order => order.batchId));
    const batches = Array.from(state.batches.values())
      .filter(batch => visibleIds.has(batch.id))
      .sort((a, b) => timestampMillis(b.importedAt) - timestampMillis(a.importedAt));
    body.innerHTML = batches.length ? batches.map(batch => {
      const locked = Months.isLocked(batch.monthId);
      const disabled = state.busy || locked ? 'disabled' : '';
      return `<tr>
        <td class="orders-id">${Utils.escapeHtml(batch.id)}</td>
        <td>${Utils.escapeHtml(Utils.monthLabelFromId(batch.monthId))}</td>
        <td>${Utils.formatNumber(batch.count)}</td>
        <td>${Utils.escapeHtml(formatDate(batch.importedAt))}</td>
        <td>${Utils.escapeHtml(batch.importedBy)}</td>
        <td class="actions-cell">
          <button class="btn btn-sm" data-batch-action="filter" data-batch-id="${Utils.escapeHtml(batch.id)}">عرض الطلبات</button>
          <button class="btn btn-sm btn-danger-outline" data-batch-action="undo" data-batch-id="${Utils.escapeHtml(batch.id)}" ${disabled}>Undo Import</button>
        </td>
      </tr>`;
    }).join('') : '<tr><td colspan="6" class="empty-state">لا توجد دفعات مطابقة</td></tr>';
  }

  function getOrder(id) {
    return state.orders.find(order => order.id === id) || null;
  }

  function modal(id, open) {
    document.getElementById(id).classList.toggle('open', open);
  }

  function openDetails(id) {
    const order = getOrder(id);
    if (!order) return;
    const rows = [
      ['Order ID', order.id], ['رقم الطلب', order.externalOrderNumber || '—'], ['التاريخ', order.orderDate || '—'],
      ['اسم العميل', order.customerName || '—'], ['رقم الهاتف', order.customerPhone || '—'], ['الملاحظات', order.notes || '—'],
      ['العنوان', order.fullAddress || '—'], ['المنتج', order.productName || '—'], ['رقم البوليصة', order.waybillNumber || '—'],
      ['المحافظة', order.governorate || '—'], ['حالة الشحنة', order.shipmentStatus || 'لم يتم التحديث'],
      ['المودريتور', order.moderatorName], ['القسم', order.departmentName],
      ['عدد الطرود', Utils.formatNumber(order.packages)], ['قيمة البيع', money(order.saleValue)],
      ['السعر', money(order.price)], ['Batch ID', order.batchId], ['الشهر', Utils.monthLabelFromId(order.monthId)],
      ['تاريخ الاستيراد', formatDate(order.importedAt)], ['المستورد بواسطة', order.importedBy],
      ['آخر تعديل', formatDate(order.updatedAt)], ['آخر تعديل بواسطة', order.updatedBy || '—']
    ];
    document.getElementById('orderDetailsGrid').innerHTML = rows.map(([label, value]) =>
      `<div class="details-stat"><div class="l">${Utils.escapeHtml(label)}</div><div class="v">${Utils.escapeHtml(String(value))}</div></div>`
    ).join('');
    modal('orderDetailsModal', true);
  }

  function fillEmployeeOptions(selected) {
    const select = document.getElementById('orderEditModerator');
    const employees = (state.callbacks.getEmployees() || []).filter(employee => employee.status !== 'inactive');
    select.innerHTML = employees.map(employee => `<option value="${Utils.escapeHtml(employee.id)}">${Utils.escapeHtml(employee.name)}</option>`).join('');
    select.value = selected || '';
  }

  function fillDepartmentOptions(selected) {
    const select = document.getElementById('orderEditDepartment');
    const departments = (state.callbacks.getDepartments() || []).filter(department => department.status !== 'archived');
    select.innerHTML = departments.map(department => `<option value="${Utils.escapeHtml(department.id)}">${Utils.escapeHtml(department.name)}</option>`).join('');
    select.value = selected || '';
  }

  function openEdit(id) {
    const order = getOrder(id);
    if (!order) return;
    if (Months.isLocked(order.monthId)) {
      Toast.show(`شهر ${Utils.monthLabelFromId(order.monthId)} مقفول ولا يمكن تعديل طلباته`, 'error');
      return;
    }
    document.getElementById('orderEditId').value = order.id;
    document.getElementById('orderEditPackages').value = order.packages;
    document.getElementById('orderEditPrice').value = order.price;
    document.getElementById('orderEditMonth').textContent = Utils.monthLabelFromId(order.monthId);
    fillEmployeeOptions(order.moderatorId);
    fillDepartmentOptions(order.departmentId);
    modal('orderEditModal', true);
  }

  async function ensureEditable(monthId, action) {
    try {
      Months.assertEditable(monthId, action);
    } catch (err) {
      throw err;
    }
  }

  function actorEmail() {
    return auth.currentUser ? (auth.currentUser.email || null) : null;
  }

  async function recalculate(monthId) {
    const ok = await state.callbacks.recalculate(monthId);
    if (!ok) throw new Error('تعذر إعادة حساب التقرير بعد تحديث الطلبات');
  }

  async function updateOrder(id) {
    Permissions.require('orders.write');
    const order = getOrder(id);
    if (!order || state.busy) return;
    const packages = Number(document.getElementById('orderEditPackages').value);
    const price = Number(document.getElementById('orderEditPrice').value);
    const moderatorId = document.getElementById('orderEditModerator').value;
    const departmentId = document.getElementById('orderEditDepartment').value;
    const employee = (state.callbacks.getEmployees() || []).find(item => item.id === moderatorId);
    if (!Number.isInteger(packages) || packages <= 0 || !Number.isFinite(price) || price < 0 || !employee || !departmentId) {
      Toast.show('راجع بيانات الطلب: الطرود رقم صحيح أكبر من صفر والسعر غير سالب', 'error');
      return;
    }
    state.busy = true;
    render();
    Loading.show('جاري تحديث الطلب وإعادة الحساب...');
    try {
      await ensureEditable(order.monthId, 'تعديل الطلب');
      await db.runTransaction(async transaction => {
        const snap = await transaction.get(order.batchRef);
        if (!snap.exists) throw new Error('دفعة الطلب لم تعد موجودة');
        const data = snap.data() || {};
        const items = Array.isArray(data.items) ? data.items.slice() : [];
        // The first management write on a legacy batch permanently assigns
        // IDs to every remaining item. That prevents an array index from
        // becoming a moving "ID" after a neighbouring legacy order is deleted.
        items.forEach((item, itemIndex) => {
          if (!item.orderId) items[itemIndex] = { ...item, orderId: orderId(order.batchId, item, itemIndex) };
        });
        const index = items.findIndex(item => item.orderId === order.id);
        if (index < 0 || !items[index]) throw new Error('تعذر العثور على الطلب داخل الدفعة');
        const before = { ...items[index] };
        const updated = {
          ...before,
          orderId: before.orderId || order.id,
          moderatorId: employee.id,
          moderatorName: employee.name,
          departmentId,
          departmentName: departmentName(departmentId),
          packages,
          price,
          saleValue: price,
          updatedAt: new Date(),
          updatedBy: actorEmail()
        };
        items[index] = updated;
        transaction.update(order.batchRef, {
          items,
          count: items.length,
          updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
          updatedBy: actorEmail()
        });
        AuditService.appendToBatch(transaction, {
          action: AuditService.ACTION.ORDERS_UPDATED,
          entity: 'orders', operation: AuditService.OPERATION.UPDATE,
          documentId: order.id, documentLabel: order.moderatorName,
          monthId: order.monthId, before, after: updated,
          details: { batchId: order.batchId, orderId: order.id, monthId: order.monthId }
        });
      });
      await recalculate(order.monthId);
      modal('orderEditModal', false);
      await load();
      Toast.show('تم تحديث الطلب وإعادة حساب التقرير', 'success');
    } catch (err) {
      console.error('Order update failed:', err);
      Toast.show('تعذر تحديث الطلب: ' + err.message, 'error');
    } finally {
      state.busy = false;
      Loading.hide();
      render();
    }
  }

  async function deleteOrder(id) {
    Permissions.require('orders.write');
    const order = getOrder(id);
    if (!order || state.busy) return;
    state.busy = true;
    render();
    Loading.show('جاري حذف الطلب وإعادة الحساب...');
    try {
      await ensureEditable(order.monthId, 'حذف الطلب');
      await db.runTransaction(async transaction => {
        const snap = await transaction.get(order.batchRef);
        if (!snap.exists) throw new Error('دفعة الطلب لم تعد موجودة');
        const data = snap.data() || {};
        const items = Array.isArray(data.items) ? data.items.slice() : [];
        items.forEach((item, itemIndex) => {
          if (!item.orderId) items[itemIndex] = { ...item, orderId: orderId(order.batchId, item, itemIndex) };
        });
        const index = items.findIndex(item => item.orderId === order.id);
        if (index < 0 || !items[index]) throw new Error('تعذر العثور على الطلب داخل الدفعة');
        const removed = items[index];
        items.splice(index, 1);
        if (items.length === 0) transaction.delete(order.batchRef);
        else transaction.update(order.batchRef, {
          items, count: items.length,
          updatedAt: firebase.firestore.FieldValue.serverTimestamp(), updatedBy: actorEmail()
        });
        AuditService.appendToBatch(transaction, {
          action: AuditService.ACTION.ORDERS_DELETED,
          entity: 'orders', operation: AuditService.OPERATION.DELETE,
          documentId: order.id, documentLabel: order.moderatorName,
          monthId: order.monthId, before: removed,
          details: { batchId: order.batchId, orderId: order.id, monthId: order.monthId }
        });
      });
      await recalculate(order.monthId);
      await load();
      Toast.show('تم حذف الطلب وإعادة حساب التقرير', 'success');
    } catch (err) {
      console.error('Order delete failed:', err);
      Toast.show('تعذر حذف الطلب: ' + err.message, 'error');
    } finally {
      state.busy = false;
      Loading.hide();
      render();
    }
  }

  async function undoBatch(batchId) {
    Permissions.require('orders.write');
    const batch = state.batches.get(batchId);
    if (!batch || state.busy) return;
    state.busy = true;
    render();
    Loading.show('جاري التراجع عن الاستيراد...');
    try {
      await ensureEditable(batch.monthId, 'التراجع عن الاستيراد');
      let removedBatch = null;
      await db.runTransaction(async transaction => {
        const snap = await transaction.get(batch.ref);
        if (!snap.exists) throw new Error('هذه الدفعة لم تعد موجودة');
        removedBatch = normalizeBatch(snap);
        transaction.delete(batch.ref);
        AuditService.appendToBatch(transaction, {
          action: AuditService.ACTION.ORDERS_BATCH_UNDONE,
          entity: 'orders', operation: AuditService.OPERATION.DELETE,
          documentId: batch.id, documentLabel: `دفعة ${batch.id}`,
          monthId: batch.monthId,
          before: { batchId: batch.id, count: removedBatch.count, autoCreatedEmployeeIds: removedBatch.autoCreatedEmployeeIds },
          details: { batchId: batch.id, monthId: batch.monthId, orderCount: removedBatch.count }
        });
      });

      // An imported employee is live master data. Removing a batch, resetting
      // its month, or deleting that month must never delete the employee.
      await recalculate(batch.monthId);
      await load();
      Toast.show('تم Undo Import وحذف طلبات الدفعة وإعادة الحساب', 'success');
    } catch (err) {
      console.error('Undo import failed:', err);
      Toast.show('تعذر التراجع عن الاستيراد: ' + err.message, 'error');
    } finally {
      state.busy = false;
      Loading.hide();
      render();
    }
  }

  function bind() {
    document.getElementById('ordersRefreshBtn').addEventListener('click', load);
    document.getElementById('ordersSearchInput').addEventListener('input', () => { state.page = 1; render(); });
    ['ordersMonthFilter', 'ordersDepartmentFilter', 'ordersModeratorFilter', 'ordersBatchFilter'].forEach(id => {
      document.getElementById(id).addEventListener('change', () => { state.page = 1; render(); });
    });
    document.getElementById('ordersPrevBtn').addEventListener('click', () => { state.page -= 1; render(); });
    document.getElementById('ordersNextBtn').addEventListener('click', () => { state.page += 1; render(); });
    document.getElementById('ordersTableBody').addEventListener('click', event => {
      const button = event.target.closest('[data-order-action]');
      if (!button) return;
      const id = button.dataset.orderId;
      if (button.dataset.orderAction === 'details') openDetails(id);
      if (button.dataset.orderAction === 'edit') openEdit(id);
      if (button.dataset.orderAction === 'delete') {
        const order = getOrder(id);
        if (order) Confirm.show(`حذف الطلب ${order.id} نهائيًا؟ سيتم إعادة حساب تقرير ${Utils.monthLabelFromId(order.monthId)}.`, () => deleteOrder(id));
      }
    });
    document.getElementById('ordersBatchesBody').addEventListener('click', event => {
      const button = event.target.closest('[data-batch-action]');
      if (!button) return;
      const batchId = button.dataset.batchId;
      if (button.dataset.batchAction === 'filter') {
        document.getElementById('ordersBatchFilter').value = batchId;
        state.page = 1;
        render();
      }
      if (button.dataset.batchAction === 'undo') {
        const batch = state.batches.get(batchId);
        if (batch) Confirm.show(`Undo Import للدفعة ${batch.id}؟ سيُحذف ${batch.count} طلبًا فقط ثم يُعاد حساب التقرير.`, () => undoBatch(batchId));
      }
    });
    document.getElementById('orderDetailsCloseBtn').addEventListener('click', () => modal('orderDetailsModal', false));
    document.getElementById('orderEditCancelBtn').addEventListener('click', () => modal('orderEditModal', false));
    document.getElementById('orderEditSaveBtn').addEventListener('click', () => updateOrder(document.getElementById('orderEditId').value));
  }

  function init(callbacks) {
    if (state.initialized) return;
    state.callbacks = callbacks;
    bind();
    state.initialized = true;
  }

  async function open() {
    if (!state.initialized) return;
    await load();
  }

  return { init, open, refresh: load };
})();
