'use strict';

const DataSources = (() => {
  let sources = [];
  const $ = id => document.getElementById(id);
  const escape = value => Utils.escapeHtml(String(value || '—'));
  function departments() { return (typeof Departments !== 'undefined' ? Departments.all() : []).filter(d => d.status !== 'archived'); }
  function options(selected) { return departments().map(d => `<option value="${escape(d.id)}" ${d.id === selected ? 'selected' : ''}>${escape(d.name)}</option>`).join(''); }
  function render() {
    const body = $('dataSourcesBody'); if (!body) return;
    body.innerHTML = sources.length ? sources.map(source => `<tr><td>${escape((departments().find(d => d.id === source.departmentId) || {}).name)}</td><td>${source.type === 'google-sheets' ? 'Google Sheets' : 'Excel'}</td><td>${escape(source.name || 'بدون اسم')}</td><td><span class="badge badge-active">جاهز للربط</span></td><td>${escape(source.lastSyncAt)}</td><td>${escape(source.lastOrderCount || 0)}</td><td><button class="btn btn-sm" data-source-edit="${escape(source.id)}">تعديل</button><button class="btn btn-sm btn-danger-outline" data-source-delete="${escape(source.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="7" class="empty-state">لا توجد مصادر بيانات مضافة</td></tr>';
  }
  function typeUI() { const google = $('dataSourceType').value === 'google-sheets'; $('dataSourceGoogleFields').classList.toggle('hidden', !google); $('dataSourceExcelFields').classList.toggle('hidden', google); }
  function editor(source = null) {
    $('dataSourceEditor').classList.remove('hidden'); $('dataSourceEditorTitle').textContent = source ? 'تعديل مصدر بيانات' : 'إضافة مصدر بيانات';
    $('dataSourceId').value = source?.id || ''; $('dataSourceType').value = source?.type || 'google-sheets'; $('dataSourceDepartment').innerHTML = options(source?.departmentId); $('dataSourceName').value = source?.name || ''; $('dataSourceUrl').value = source?.url || ''; $('dataSourceSheetName').value = source?.sheetName || ''; $('dataSourceRange').value = source?.range || ''; typeUI();
  }
  async function persist() { await db.collection(COLLECTIONS.SETTINGS).doc('general').set({ dataSources: sources, updatedAt: firebase.firestore.FieldValue.serverTimestamp() }, { merge: true }); }
  async function save() {
    const type = $('dataSourceType').value, departmentId = $('dataSourceDepartment').value, url = $('dataSourceUrl').value.trim();
    if (!departmentId) return Toast.show('اختر القسم المرتبط بالمصدر', 'error');
    if (type === 'google-sheets' && (!/^https:\/\/docs\.google\.com\/spreadsheets\//.test(url) || !$('dataSourceSheetName').value.trim())) return Toast.show('أدخل رابط Google Sheet صحيحًا واسم الـ Sheet', 'error');
    if (type === 'excel' && !$('dataSourceExcelFile').files.length && !$('dataSourceId').value) return Toast.show('اختر ملف Excel للمصدر', 'error');
    const id = $('dataSourceId').value || db.collection(COLLECTIONS.SETTINGS).doc().id; const source = { id, type, departmentId, name: $('dataSourceName').value.trim(), url: type === 'google-sheets' ? url : '', sheetName: type === 'google-sheets' ? $('dataSourceSheetName').value.trim() : '', range: type === 'google-sheets' ? $('dataSourceRange').value.trim() : '', lastSyncAt: sources.find(s => s.id === id)?.lastSyncAt || null, lastOrderCount: sources.find(s => s.id === id)?.lastOrderCount || 0 };
    sources = sources.filter(s => s.id !== id).concat(source); await persist(); render(); $('dataSourceEditor').classList.add('hidden'); Toast.show('تم حفظ مصدر البيانات', 'success');
  }
  async function remove(id) { sources = sources.filter(s => s.id !== id); await persist(); render(); Toast.show('تم حذف مصدر البيانات', 'success'); }
  async function load() { const snap = await db.collection(COLLECTIONS.SETTINGS).doc('general').get(); sources = snap.exists && Array.isArray(snap.data().dataSources) ? snap.data().dataSources : []; render(); }
  function bind() {
    $('dataSourceAddBtn').addEventListener('click', () => editor()); $('dataSourceType').addEventListener('change', typeUI); $('dataSourceCancelBtn').addEventListener('click', () => $('dataSourceEditor').classList.add('hidden')); $('dataSourceSaveBtn').addEventListener('click', save);
    $('dataSourceTestBtn').addEventListener('click', () => { const url = $('dataSourceUrl').value.trim(); Toast.show(/^https:\/\/docs\.google\.com\/spreadsheets\//.test(url) && $('dataSourceSheetName').value.trim() ? 'بيانات الاتصال صحيحة وجاهزة للربط لاحقًا' : 'راجع رابط Google Sheet واسم الـ Sheet', /^https:\/\/docs\.google\.com\/spreadsheets\//.test(url) ? 'success' : 'error'); });
    $('dataSourcesBody').addEventListener('click', event => { const edit = event.target.closest('[data-source-edit]'), del = event.target.closest('[data-source-delete]'); if (edit) editor(sources.find(s => s.id === edit.dataset.sourceEdit)); if (del) Confirm.show('حذف مصدر البيانات؟', () => remove(del.dataset.sourceDelete)); });
  }
  function openSync() { Toast.show(sources.length ? `المصادر الجاهزة للمزامنة: ${sources.map(s => s.name || s.type).join('، ')}. الربط الفعلي سيُضاف في مرحلة لاحقة.` : 'لا توجد مصادر مفعلة للمزامنة', 'info'); }
  function init() { bind(); $('dataSourcesSyncBtn').addEventListener('click', openSync); load().catch(error => { console.error('Data sources load failed', error); Toast.show('تعذر تحميل مصادر البيانات', 'error'); }); }
  return { init };
})();
