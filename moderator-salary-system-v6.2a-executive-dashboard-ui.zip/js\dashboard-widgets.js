'use strict';

/* Reusable, read-only Dashboard UI primitives. Data-bound widgets continue to
   be rendered by the existing controller; unavailable operational datasets
   intentionally show an explicit empty state. */
const DashboardWidgets = (() => {
  function empty(title) {
    return `<section class="panel executive-widget"><div class="panel-header"><h3>${Utils.escapeHtml(title)}</h3></div><div class="widget-empty">No data available yet</div></section>`;
  }
  function init() {
    const mount = document.getElementById('dashboardOperationalWidgets');
    if (mount) mount.innerHTML = [empty('حالة الشحن'), empty('أفضل المنتجات'), empty('أفضل المحافظات'), empty('آخر النشاطات')].join('');
  }
  return { init, empty };
})();
