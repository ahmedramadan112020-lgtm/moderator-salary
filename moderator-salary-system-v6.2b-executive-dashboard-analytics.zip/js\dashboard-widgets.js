'use strict';

/* Reusable, read-only Dashboard UI primitives. Data-bound widgets continue to
   be rendered by the existing controller; unavailable operational datasets
   intentionally show an explicit empty state. */
const DashboardWidgets = (() => {
  function empty(title) {
    return `<section class="panel executive-widget"><div class="panel-header"><h3>${Utils.escapeHtml(title)}</h3></div><div class="widget-empty">No data available yet</div></section>`;
  }
  const n = value => Utils.formatNumber(value || 0);
  const pct = (value, total) => total ? `${((value / total) * 100).toFixed(1)}%` : '0%';
  const statusCount = (orders, label) => orders.filter(o => Utils.normalizeName(o.shipmentStatus).includes(label)).length;
  function ranked(orders, key, label) {
    const map = new Map(); orders.forEach(order => { const name = order[key] || 'غير محدد'; const current = map.get(name) || { name, orders: 0, sales: 0, delivered: 0 }; current.orders++; current.sales += Number(order.price || 0); current.delivered += Utils.normalizeName(order.shipmentStatus).includes('تسليم') ? 1 : 0; map.set(name, current); });
    const rows = Array.from(map.values()).sort((a,b) => b.orders - a.orders || b.sales - a.sales).slice(0,5); return `<section class="panel executive-widget"><div class="panel-header"><h3>${label}</h3></div>${rows.length ? `<div class="widget-ranking">${rows.map((r,i) => `<div><strong>${i+1}. ${Utils.escapeHtml(r.name)}</strong><span>${n(r.orders)} طلب · ${pct(r.delivered,r.orders)} تسليم · ${Utils.formatCurrency(r.sales)}</span></div>`).join('')}</div>` : '<div class="widget-empty">No data available yet</div>'}</section>`;
  }
  function alerts(orders) {
    const total = orders.length, returned = statusCount(orders, 'مرتجع'), unknown = statusCount(orders, 'لم يتم التحديث'); const list = [];
    if (total && returned / total >= .15) list.push(['alert-warning','ارتفاع نسبة المرتجع',`${pct(returned,total)} من الطلبات حالتها مرتجع.`]);
    if (unknown) list.push(['alert-info','طلبات تحتاج تحديث',`${n(unknown)} طلبًا لم يتم تحديث حالة شحنه.`]);
    if (!list.length) list.push(['alert-success','لا توجد تنبيهات تشغيلية', total ? 'حالات الشحن ضمن النطاق الطبيعي.' : 'No data available yet']);
    const node = document.getElementById('dashboardAlertsGrid'); if (node) node.innerHTML = list.map(([c,t,d]) => `<div class="alert-card ${c}"><span class="alert-icon">ℹ</span><div><strong>${t}</strong><p>${d}</p></div></div>`).join('');
  }
  function shipping(orders) {
    const total = orders.length; const rows = [['تم التسليم',statusCount(orders,'تسليم')],['مرتجع',statusCount(orders,'مرتجع')],['مؤجل',statusCount(orders,'مؤجل')],['في الشحن',statusCount(orders,'شحن')]];
    return `<section class="panel executive-widget"><div class="panel-header"><h3>حالة الشحن</h3></div>${total ? `<div class="widget-ranking">${rows.map(([label,value]) => `<div><strong>${label}</strong><span>${n(value)} · ${pct(value,total)}</span></div>`).join('')}</div>` : '<div class="widget-empty">No data available yet</div>'}</section>`;
  }
  function refresh() {
    const orders = typeof OrdersManagement === 'undefined' ? [] : OrdersManagement.getAll();
    const mount = document.getElementById('dashboardOperationalWidgets'); if (!mount) return;
    mount.innerHTML = [shipping(orders), ranked(orders,'productName','أفضل المنتجات'), ranked(orders,'governorate','أفضل المحافظات'), ranked(orders,'moderatorName','أفضل الموظفين'), ranked(orders,'departmentName','أفضل الأقسام')].join(''); alerts(orders);
  }
  function init() {
    const mount = document.getElementById('dashboardOperationalWidgets');
    if (mount) mount.innerHTML = [empty('حالة الشحن'), empty('أفضل المنتجات'), empty('أفضل المحافظات'), empty('آخر النشاطات')].join('');
  }
  return { init, refresh, empty };
})();
