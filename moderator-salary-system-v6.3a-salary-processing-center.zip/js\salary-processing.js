'use strict';

/* Independent approval layer: snapshots never mutate the operational report. */
const SalaryProcessing = (() => {
  const collection = 'salary_processing';
  const $ = id => document.getElementById(id);
  async function status() {
    const context = App.getSalaryProcessingContext(); if (!context.monthId) return;
    const snap = await db.collection(collection).doc(context.monthId).get(); const node = $('salaryProcessingStatus');
    if (node) { node.textContent = snap.exists && snap.data().status === 'approved' ? 'Approved' : 'Draft'; node.className = `badge ${snap.exists && snap.data().status === 'approved' ? 'badge-approved' : 'badge-locked'}`; }
  }
  async function approve() {
    const context = App.getSalaryProcessingContext();
    if (!context.monthId || !context.rows.length) return Toast.show('أنشئ التقرير أولاً قبل الاعتماد', 'error');
    const ref = db.collection(collection).doc(context.monthId); const existing = await ref.get();
    if (existing.exists && existing.data().status === 'approved') return Toast.show('هذه الفترة معتمدة بالفعل', 'info');
    const snapshot = { version: 1, period: { type:'month', monthId:context.monthId }, status:'approved', approvedAt: firebase.firestore.FieldValue.serverTimestamp(), approvedBy: auth.currentUser ? auth.currentUser.email || null : null, report: context.rows.map(row => ({ ...row })), totals: context.totals, employeeManualEntries: {}, payment: { status:'unpaid', paidAt:null, paidBy:null }, createdAt: firebase.firestore.FieldValue.serverTimestamp(), updatedAt: firebase.firestore.FieldValue.serverTimestamp() };
    await ref.set(snapshot, { merge:false }); await status(); Toast.show('تم حفظ Snapshot الرواتب المعتمد بشكل مستقل', 'success');
  }
  function init() { $('salarySnapshotApproveBtn').addEventListener('click', () => approve().catch(error => { console.error('Payroll approval failed', error); Toast.show('تعذر اعتماد الرواتب: ' + error.message, 'error'); })); status().catch(()=>{}); }
  return { init, status };
})();
