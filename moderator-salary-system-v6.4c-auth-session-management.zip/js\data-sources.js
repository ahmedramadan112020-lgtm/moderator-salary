'use strict';

const DataSources = (() => {
  let sources = [];
  const $ = id => document.getElementById(id);
  const escape = value => Utils.escapeHtml(String(value || '—'));
  function departments() { return (typeof Departments !== 'undefined' ? Departments.all() : []).filter(d => d.status !== 'archived'); }
  function options(selected) { return departments().map(d => `<option value="${escape(d.id)}" ${d.id === selected ? 'selected' : ''}>${escape(d.name)}</option>`).join(''); }
  function render() {
    const body = $('dataSourcesBody'); if (!body) return;
    body.innerHTML = sources.length ? sources.map(source => `<tr><td>${escape((departments().find(d => d.id === source.departmentId) || {}).name)}</td><td>${source.type === 'google-sheets' ? 'Google Sheets' : 'Excel'}</td><td>${escape(source.name || 'بدون اسم')}</td><td><span class="badge badge-active">جاهز للربط</span></td><td>${escape(source.lastSyncAt)}</td><td>${escape(source.lastOrderCount || 0)}</td><td><button class="btn btn-sm" data-source-edit="${escape(source.id)}">تعديل</button><button class="btn btn-sm btn-danger-outline" data-source-delete="${escape(source.id)}">حذف</button></td></tr>`).join('') : '<tr><td colspan="7" class="empty-state">لا توجد مصادر بيانات مضافة</td></tr>';
  }
  function typeUI() { const google = $('dataSourceType').value === 'google-sheets'; $('dataSourceGoogleFields').classList.toggle('hidden', !google); $('dataSourceExcelFields').classList.toggle('hidden', google); }
  function editor(source = null) {
    $('dataSourceEditor').classList.remove('hidden'); $('dataSourceEditorTitle').textContent = source ? 'تعديل مصدر بيانات' : 'إضافة مصدر بيانات';
    $('dataSourceId').value = source?.id || ''; $('dataSourceType').value = source?.type || 'google-sheets'; $('dataSourceDepartment').innerHTML = options(source?.departmentId); $('dataSourceName').value = source?.name || ''; $('dataSourceUrl').value = source?.url || ''; $('dataSourceSheetName').value = source?.sheetName || ''; $('dataSourceRange').value = source?.range || ''; typeUI();
  }
  async function persist() { await db.collection(COLLECTIONS.SETTINGS).doc('general').set({ dataSources: sources, updatedAt: firebase.firestore.FieldValue.serverTimestamp() }, { merge: true }); }
  async function save() {
    const type = $('dataSourceType').value, departmentId = $('dataSourceDepartment').value, url = $('dataSourceUrl').value.trim();
    if (!departmentId) return Toast.show('اختر القسم المرتبط بالمصدر', 'error');
    if (type === 'google-sheets' && (!/^https:\/\/docs\.google\.com\/spreadsheets\//.test(url) || !$('dataSourceSheetName').value.trim())) return Toast.show('أدخل رابط Google Sheet صحيحًا واسم الـ Sheet', 'error');
    if (type === 'excel' && !$('dataSourceExcelFile').files.length && !$('dataSourceId').value) return Toast.show('اختر ملف Excel للمصدر', 'error');
    const id = $('dataSourceId').value || db.collection(COLLECTIONS.SETTINGS).doc().id; const source = { id, type, departmentId, name: $('dataSourceName').value.trim(), url: type === 'google-sheets' ? url : '', sheetName: type === 'google-sheets' ? $('dataSourceSheetName').value.trim() : '', range: type === 'google-sheets' ? $('dataSourceRange').value.trim() : '', lastSyncAt: sources.find(s => s.id === id)?.lastSyncAt || null, lastOrderCount: sources.find(s => s.id === id)?.lastOrderCount || 0 };
    sources = sources.filter(s => s.id !== id).concat(source); await persist(); render(); $('dataSourceEditor').classList.add('hidden'); Toast.show('تم حفظ مصدر البيانات', 'success');
  }
  async function remove(id) { sources = sources.filter(s => s.id !== id); await persist(); render(); Toast.show('تم حذف مصدر البيانات', 'success'); }
  async function load() { const snap = await db.collection(COLLECTIONS.SETTINGS).doc('general').get(); sources = snap.exists && Array.isArray(snap.data().dataSources) ? snap.data().dataSources : []; render(); }
  function bind() {
    $('dataSourceAddBtn').addEventListener('click', () => editor()); $('dataSourceType').addEventListener('change', typeUI); $('dataSourceCancelBtn').addEventListener('click', () => $('dataSourceEditor').classList.add('hidden')); $('dataSourceSaveBtn').addEventListener('click', save);
    $('dataSourceTestBtn').addEventListener('click', () => { const url = $('dataSourceUrl').value.trim(); Toast.show(/^https:\/\/docs\.google\.com\/spreadsheets\//.test(url) && $('dataSourceSheetName').value.trim() ? 'بيانات الاتصال صحيحة وجاهزة للربط لاحقًا' : 'راجع رابط Google Sheet واسم الـ Sheet', /^https:\/\/docs\.google\.com\/spreadsheets\//.test(url) ? 'success' : 'error'); });
    $('dataSourcesBody').addEventListener('click', event => { const edit = event.target.closest('[data-source-edit]'), del = event.target.closest('[data-source-delete]'); if (edit) editor(sources.find(s => s.id === edit.dataset.sourceEdit)); if (del) Confirm.show('حذف مصدر البيانات؟', () => remove(del.dataset.sourceDelete)); });
  }
  function csvRows(text) {
    return text.trim().split(/\r?\n/).map(line => line.split(',').map(cell => cell.replace(/^"|"$/g, '').trim()));
  }
  const aliases = { orderDate: ['التاريخ', 'date'], externalOrderNumber: ['رقمالطلب', 'ordernumber', 'orderid'], customerName: ['اسمالعميل', 'customername', 'customer'], customerPhone: ['رقمالهاتف', 'phone', 'mobile'], notes: ['ملاحظات', 'notes'], fullAddress: ['العنوان', 'address'], productName: ['اسمالمنتج', 'productname', 'product'], packages: ['عددالعبوات', 'العبوات', 'packages', 'qty'], price: ['السعر', 'price'], name: ['اسمالموظف', 'الموظف', 'employee', 'employeename'] };
  const norm = value => Utils.normalizeName(value).replace(/[^a-z0-9\u0600-\u06FF]/g, '');
  function reviewSimilar(rows, similar, source) {
    return new Promise(resolve => {
      const byIndex = new Map(similar.map(item => [item.index, item]));
      const modal = document.createElement('div'); modal.className = 'modal-backdrop open';
      const newDepartment = (departments().find(d => d.id === source.departmentId) || {}).name || '—';
      modal.innerHTML = `<div class="modal" style="max-width:1100px"><div class="modal-header"><h2>الأوردرات المتشابهة</h2></div><p class="panel-subtitle">وجود الاسم والهاتف نفسيهما ليس خطأ؛ اختر القرار بنفسك لكل أوردر.</p><div class="wizard-actions"><button class="btn" data-review-all-import>استيراد جميع الأوردرات كطلبات جديدة</button><button class="btn btn-danger-outline" data-review-all-skip>تخطي جميع الأوردرات المتشابهة</button></div><div class="table-wrap"><table><thead><tr><th>اسم العميل</th><th>رقم الهاتف</th><th>تاريخ الطلب الموجود</th><th>تاريخ الطلب الجديد</th><th>القسم الموجود</th><th>القسم الجديد</th><th>الموظف الموجود</th><th>الموظف الجديد</th><th>القرار</th></tr></thead><tbody>${similar.map(item => { const row = rows[item.index]; return `<tr><td>${escape(row.customerName)}</td><td>${escape(row.customerPhone)}</td><td>${escape(item.existing.orderDate || '—')}</td><td>${escape(row.orderDate || '—')}</td><td>${escape(item.existing.departmentName || '—')}</td><td>${escape(newDepartment)}</td><td>${escape(item.existing.moderatorName || '—')}</td><td>${escape(row.name || '—')}</td><td><select data-similar-index="${item.index}"><option value="import">استيراد كأوردر جديد</option><option value="skip">تخطي</option></select></td></tr>`; }).join('')}</tbody></table></div><div class="wizard-actions"><button class="btn" data-review-cancel>إلغاء</button><button class="btn btn-accent" data-review-confirm>متابعة</button></div></div>`;
      document.body.appendChild(modal); modal.querySelector('[data-review-cancel]').onclick = () => { modal.remove(); resolve(null); }; modal.querySelector('[data-review-confirm]').onclick = () => { const skipped = []; modal.querySelectorAll('[data-similar-index]').forEach(select => { if (select.value === 'skip') skipped.push(Number(select.dataset.similarIndex)); }); modal.remove(); resolve(skipped); };
      modal.querySelector('[data-review-all-import]').onclick = () => modal.querySelectorAll('[data-similar-index]').forEach(select => { select.value = 'import'; });
      modal.querySelector('[data-review-all-skip]').onclick = () => modal.querySelectorAll('[data-similar-index]').forEach(select => { select.value = 'skip'; });
    });
  }
  async function sync(source) {
    try {
      const sheet = encodeURIComponent(source.sheetName); const range = source.range ? `&range=${encodeURIComponent(source.range)}` : '';
      const url = source.url.replace(/\/edit.*$/, '') + `/gviz/tq?tqx=out:csv&sheet=${sheet}${range}`;
      const response = await fetch(url); if (!response.ok) throw new Error(`فشل الاتصال (${response.status})`);
      const rows = csvRows(await response.text()); const headers = rows.shift() || []; const map = Object.fromEntries(Object.entries(aliases).map(([field, names]) => [field, headers.findIndex(header => names.includes(norm(header)))]));
      const required = ['name', 'packages', 'price']; const errors = []; const orders = [];
      rows.forEach((row, index) => { const read = field => map[field] >= 0 ? String(row[map[field]] || '').trim() : ''; const packages = Number(read('packages')), price = Number(read('price')); if (!read('name') || !Number.isInteger(packages) || packages <= 0 || !Number.isFinite(price) || price < 0) { errors.push({ lineNumber: index + 2 }); return; } orders.push({ name: read('name'), packages, price, orderDate: read('orderDate'), externalOrderNumber: read('externalOrderNumber'), customerName: read('customerName'), customerPhone: read('customerPhone'), notes: read('notes'), fullAddress: read('fullAddress'), productName: read('productName'), waybillNumber: '', governorate: '', shipmentStatus: 'لم يتم التحديث' }); });
      const similar = await App.findSimilarGoogleOrders(orders); const skipped = similar.length ? await reviewSimilar(orders, similar, source) : [];
      if (skipped === null) return;
      const selected = orders.filter((_, index) => !skipped.includes(index)); const result = await App.syncGoogleSource(source, selected, errors, skipped.length); source.lastSyncAt = new Date().toLocaleString('ar-EG'); source.lastOrderCount = result.imported || 0; source.lastSyncStatus = 'success'; await persist(); render(); Toast.show(`اكتملت مزامنة ${source.name || source.sheetName}: ${orders.length} مقروء، ${result.imported || 0} جديد، ${skipped.length} تم تخطيه، ${errors.length} أخطاء`, 'success');
    } catch (error) { source.lastSyncAt = new Date().toLocaleString('ar-EG'); source.lastOrderCount = 0; source.lastSyncStatus = 'error'; await persist(); render(); Toast.show('تعذر مزامنة المصدر: ' + error.message, 'error'); }
  }
  async function openSync() { const google = sources.filter(s => s.type === 'google-sheets'); if (!google.length) return Toast.show('لا توجد مصادر Google Sheets مفعلة', 'info'); const choice = window.prompt(`اختر رقم المصدر للمزامنة، أو اكتب all لمزامنة الجميع:\n${google.map((s, i) => `${i + 1}. ${s.name || s.sheetName}`).join('\n')}`, 'all'); if (!choice) return; const selected = choice.toLowerCase() === 'all' ? google : [google[Number(choice) - 1]].filter(Boolean); if (!selected.length) return Toast.show('اختيار المصدر غير صحيح', 'error'); for (const source of selected) await sync(source); }
  function init() { bind(); $('dataSourcesSyncBtn').addEventListener('click', openSync); load().catch(error => { console.error('Data sources load failed', error); Toast.show('تعذر تحميل مصادر البيانات', 'error'); }); }
  return { init };
})();
