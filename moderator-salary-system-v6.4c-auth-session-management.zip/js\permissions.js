/* Roles + Permissions ---------------------------------------------------
 * The effective permission list is stored on the user profile. Roles are
 * templates only; per-user allow/deny overrides are resolved before saving.
 * This module is intentionally dependency-free so screens and services use
 * one vocabulary for authorisation.
 */
'use strict';

const Permissions = (() => {
  const ROLES = {
    owner: { label: 'Owner', permissions: ['*'], system: true },
    super_admin: { label: 'Owner', permissions: ['*'], system: true },
    admin: { label: 'Admin', permissions: [
      'dashboard.read','departments.read','departments.write','employees.read','employees.write','employees.delete',
      'orders.read','orders.write','orders.import','months.read','months.write','months.destructive',
      'reports.read','reports.calculate','reports.export','reports.approve','transactions.read','transactions.write',
      'settlements.read','settlements.write','backups.read','backups.create','backups.restore','backups.download',
      'archive.read','comparison.read','audit.read','settings.read','settings.write'
    ] },
    accountant: { label: 'Accountant', permissions: [
      'dashboard.read','employees.read','departments.read','orders.read','months.read','reports.read','reports.calculate','reports.export',
      'transactions.read','transactions.write','settlements.read','backups.read','backups.download','archive.read','comparison.read','audit.read'
    ] },
    hr: { label: 'HR', permissions: [
      'dashboard.read','departments.read','departments.write','employees.read','employees.write','orders.read','months.read','reports.read'
    ] },
    viewer: { label: 'Viewer', permissions: ['dashboard.read','months.read','reports.read','archive.read','comparison.read'] },
    sales_manager: { label: 'Sales Manager', permissions: ['dashboard.read','orders.read','orders.import','reports.read','reports.export'] },
    supervisor: { label: 'Supervisor', permissions: ['dashboard.read','employees.read','orders.read','reports.read'] },
    shipping: { label: 'Shipping', permissions: ['dashboard.read','orders.read','orders.write'] },
    data_entry: { label: 'Data Entry', permissions: ['dashboard.read','orders.read','orders.import'] },
    pending: { label: 'Pending', permissions: [] }
  };
  const VALID_STATUSES = ['active', 'suspended', 'pending', 'disabled'];
  let profile = null;

  // Legacy accounts without a persisted permission profile remain fully
  // functional; their administrator can later assign a role explicitly.
  function normalizeRole(role) { return ROLES[role] ? role : 'owner'; }
  function profileRole(value = profile) { return normalizeRole((value && value.systemRole) || (value && value.role)); }
  function effective(role, overrides = {}) {
    const base = ROLES[normalizeRole(role)].permissions;
    if (base.includes('*')) return ['*'];
    const set = new Set(base);
    (overrides.allow || []).forEach(p => set.add(p));
    (overrides.deny || []).forEach(p => set.delete(p));
    return [...set].sort();
  }
  function setProfile(value) { profile = value || {}; }
  function isActive() { return profile && (profile.status || 'active') === 'active'; }
  function can(permission) {
    if (!isActive()) return false;
    const list = Array.isArray(profile.permissions) ? profile.permissions : effective(profileRole(), profile.permissionOverrides);
    return list.includes('*') || list.includes(permission);
  }
  function require(permission) {
    if (!can(permission)) throw new Error('ليس لديك صلاحية تنفيذ هذه العملية.');
  }
  function roleOptions() { return Object.entries(ROLES).filter(([id]) => id !== 'pending').map(([id, r]) => ({ id, ...r })); }
  function applyUI() {
    const views = { dashboard:'dashboard.read', departments:'departments.read', moderators:'employees.read', import:'orders.import', orders:'orders.read', months:'months.read', 'month-comparison':'comparison.read', report:'reports.read', transactions:'transactions.read', settlement:'settlements.read', archive:'archive.read', backups:'backups.read', audit:'audit.read', settings:'settings.read', users:'users.manage' };
    document.querySelectorAll('.nav-item[data-view]').forEach(el => { el.hidden = !can(views[el.dataset.view] || 'dashboard.read'); });
    document.querySelectorAll('[data-permission]').forEach(el => {
      const allowed = can(el.dataset.permission);
      el.disabled = !allowed;
      el.hidden = el.dataset.permissionMode === 'hide' && !allowed;
      if (!allowed) el.title = 'ليس لديك صلاحية لهذه العملية';
    });
  }
  return { ROLES, VALID_STATUSES, normalizeRole, profileRole, effective, setProfile, can, require, roleOptions, applyUI };
})();
