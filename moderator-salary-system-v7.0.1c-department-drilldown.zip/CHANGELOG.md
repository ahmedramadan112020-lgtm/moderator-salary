# Changelog

## 7.0.0-stable

- Performed static JavaScript validation across all application modules.
- Consolidated the production handoff around central services for permissions, audit records, backups, orders, salary snapshots, and authentication metadata.
- Confirmed optional, backward-compatible storage for salary snapshots, data sources, user security metadata, and payment status.
- Documented intentional client-side limitations: revoking sessions on other devices requires Firebase Admin SDK / Cloud Functions; Google Sheets requires a publicly readable, CORS-accessible sheet.
